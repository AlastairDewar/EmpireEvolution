<?PHP
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="StyleSheet" href="../Style.css" type="text/css" media="screen" />
<title>Empire Evolution Forums</title>
</head>
<body>
<div id="Menu"><div id="scrollTop">&nbsp;</div><div id="MenuContent"><br/>
			<p><h1>Welcome to Empire Evolution Forums!</h1></p>
			<p>Empire Evolution forums are currently shut whilst under development. Expect them to opened with the first full public release of Empire Evolution.</p>
			<p style="font-size:12px; top:15px; position:relative;"><a href="?Page=TermsAndConditions">Terms &amp; Conditions</a> || <a href="?Page=PrivacyPolicy">Privacy Policy</a></p>
			<p style="font-size:12px;">Empire Evolution was created and developed by <a href="http://www.alastairdewar.co.uk">Alastair Dewar</a>.</p><br/>
</div><div id="scrollBottom">&nbsp;</div></div>
</body>
</html>