<?PHP
class Player
{
var $Username = 'Guest';
var $Password = '';
var $Rights = 0;
var $Gold = 0;
var $Stone = 0;
var $Lumber = 0;
}
?>