<?PHP
class Settings
{
var $WebsiteAddress = "http://localhost/EmpireEvoltuion/";
}
?>