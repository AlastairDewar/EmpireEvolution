<?PHP

				$Database = mysql_connect('alastairdewar.co.uk','adewar','0a4h0d62f4h1d0!!') or die(error('MySQL server down.'));
				$Database = mysql_select_db('adewar_EmpireEvolution',$Database) or die(error('Database Corrupted.'));

if(isset($_GET[Page]))
{
	if($_GET[Page] != null)
	{
		if(!is_numeric($_GET[Page]))
		{
			$Page = strtolower($_GET[Page]);
			if(strcmp($Page,'home') == 0 || $Page == null){Include("./pages/Home.ws");}else{
			if(strcmp($Page,'login') == 0){Include("./pages/Login.ws");}else{
			if(strcmp($Page,'logout') == 0){Include("./pages/Logout.ws");}else{
			if(strcmp($Page,'news') == 0){Include("./pages/News.ws");}else{
			if(strcmp($Page,'donate') == 0){Include("./pages/Donate.ws");}else{
			if(strcmp($Page,'newsarchive') == 0){Include("./pages/NewsArchive.ws");}else{
			if(strcmp($Page,'about') == 0){Include("./pages/About.ws");}else{
			if(strcmp($Page,'register') == 0){Include("./pages/Register.ws");}else{
			if(strcmp($Page,'createalliance') == 0){Include("./pages/CreateAlliance.ws");}else{
			if(strcmp($Page,'removefriend') == 0){Include("./pages/RemoveFriend.ws");}else{
			if(strcmp($Page,'addfriend') == 0){Include("./pages/AddFriend.ws");}else{
			if(strcmp($Page,'changeemail') == 0){Include("./pages/ChangeEmail.ws");}else{
			if(strcmp($Page,'changepassword') == 0){Include("./pages/ChangePassword.ws");}else{
			if(strcmp($Page,'forgottenpassword') == 0){Include("./pages/ForgottenPassword.ws");}else{
			if(strcmp($Page,'screenshots') == 0){Include("./pages/Screenshots.ws");}else{
			if(strcmp($Page,'resendconfirmation') == 0){Include("./pages/ResendConfirmation.ws");}else{
			if(strcmp($Page,'termsandconditions') == 0){Include("./pages/TermsAndConditions.ws");}else{
			if(strcmp($Page,'privacypolicy') == 0){Include("./pages/PrivacyPolicy.ws");}else{
			if(strcmp($Page,'faq') == 0){Include("./pages/FAQ.ws");}else{
			die(error('404 - Page Not Found'));}}}}}}}}}}}}}}}}}}}
		}
		else
		{
			die(error('Page value is numeric.'));
		}
	}
}
else
{
	if(isset($_GET[NewsArticle]))
	{
		if(is_numeric($_GET[NewsArticle])){
			Require("./pages/NewsArticle.ws");}
		else{
		die(error('News Article ID isn\'t numeric.'));}
	}
	else
	{
		if(isset($_GET[NewsComments])){
			if(is_numeric($_GET[NewsComments])){
				Require("./pages/NewsComments.ws");}
			else{
			die(error('News Comments ID isn\'t numeric.'));}
		}
		else
		{
			if(isset($_GET[ReportComment])){
				if(is_numeric($_GET[ReportComment])){
					Require("./pages/ReportComment.ws");}
				else{
				die(error('Report Comment ID isn\'t numeric.'));}
			}
			else
			{
				if(isset($_GET[AddComment])){
					if(is_numeric($_GET[AddComment])){
						Require("./pages/AddComment.ws");}
					else{
					die(error('Add Comment ID isn\'t numeric.'));}
				}
				else
					{
						if(isset($_GET[ReplyToComment])){
							if(is_numeric($_GET[ReplyToComment])){
								Require("./pages/ReplyToComment.ws");}
							else{
							die(error('Reply To Comment ID isn\'t numeric.'));}
						}
						else
						{
							if(isset($_GET[EditComment])){
								if(is_numeric($_GET[EditComment])){
									Require("./pages/EditComment.ws");}
								else{
								die(error('Edit Comment ID isn\'t numeric.'));}
							}
							else
							{
								Require("./pages/Home.ws");
							}
						}
					}
			}
		}
	}
}

?>