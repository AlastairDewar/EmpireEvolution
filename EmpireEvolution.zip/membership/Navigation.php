<?PHP

				$Database = mysql_connect('alastairdewar.co.uk','adewar','0a4h0d62f4h1d0!!') or die(error('MySQL server down.'));
				$Database = mysql_select_db('adewar_EmpireEvolution',$Database) or die(error('Database Corrupted.'));

if(isset($_GET[Page])){
	if($_GET[Page] != null){
		if(!is_numeric($_GET[Page])){
			$Page = strtolower($_GET[Page]);
			if(strcmp($Page,'about') == 0 || $Page == null){Include("../pages/Membership.ws");}else{
			die(error('404 - Page Not Found'));}
		}else{
			die(error('Page value is numeric.'));}}else{die(error('Page value is\'nt set.'));}}
else{
		Require("../pages/Membership.ws");}

?>