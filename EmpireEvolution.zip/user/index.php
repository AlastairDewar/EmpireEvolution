<?PHP
session_start();
?>
<!DOCTYPE html PUBLIC
  "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <title>Empire Evolution</title>
    <link rel="stylesheet" href="http://empireevolution.uk.to/Style.css" type="text/css" media="screen" />
  </head>
  <body>
  <div id="banner" onclick="location.href='http://empireevolution.uk.to/';" ></div>
  <div id="scroll">
  <div id="scrollTop">&nbsp;</div>
  <div id="scrollBackdrop">&nbsp;
  <div id="scrollContent">

<?PHP

require('../functions/error.ws');
require('../functions/loggedIn.ws');

$Database = mysql_connect('alastairdewar.co.uk', 'adewar', '0a4h0d62f4h1d0!!');
$Database = mysql_select_db('adewar_EmpireEvolution',$Database);

	if(isset($_GET[User]) && $_GET[User] != null && !is_numeric($_GET[User]))
	{
	$User = mysql_query("SELECT * FROM Player WHERE Username='".$_GET[User]."' LIMIT 1;") or die(mysql_error());
	if(mysql_num_rows($User) == 1)
	{
		$User = mysql_fetch_array($User);
		$Alliance = mysql_query("SELECT * FROM Alliances WHERE UID='".$User[Alliance]."' LIMIT 1;");
		$Referrals = mysql_num_rows(mysql_query("SELECT * FROM Referrals WHERE RefererUID='".$User[ID]."';"));
		Echo('
			<table border="0" width="100%">
			<tr><td>Username</td><td>'.$User[Username].'</td></tr>
			<tr><td>Private Message</td><td><a href="../?SendMessage='.$User[ID].'"><img src="../images/icons/SendMessage.png" width="16" height="16" alt="Send PM"/></a></td></tr>
			<tr><td>Location</td><td><img src="../images/flags/'.strtolower($User[Location]).'.gif" width="16" height="11" alt="Unknown"/></td></tr>
			<tr><td>Number of Referrals</td><td>'.$Referrals.'</td></tr>');
			if(mysql_num_rows($Alliance) == 1)
			{
			$Alliance = mysql_fetch_array($Alliance);
			Echo('<tr><td>Alliance</td><td><a href="../alliance/'.str_replace(' ','_',$Alliance[Name]).'">'.$Alliance[Name].'</a></td></tr>');
			}
			else
			{
			Echo('<tr><td>Alliance</td><td>None</td></tr>');
			}
			Echo('<tr><td>Rank</td><td>1,000,000</td></tr>
			<tr><td>Statistics</td><td>');
			if(loggedIn())
			{
			$Scouted = mysql_query("SELECT * FROM Scouting WHERE Scouted = '".$User[ID]."' AND Scoutee = '".$_SESSION[UID]."'");
			if(mysql_num_rows($Scouted) == 1 || loggedIn() && $_SESSION[UID] == $User[ID])
			{
			Echo('<img width="30" height="34" src="../images/icons/Gold.gif" alt="Gold:">&nbsp;'.number_format($User[Gold]).'<br/><img src="../images/icons/Stone.gif" width="32" height="32" alt="Stone:">&nbsp;'.number_format($User[Stone]).'<br/><img width="30" height="34" src="../images/icons/Logs.gif" alt="Lumber:">&nbsp;'.number_format($User[Lumber]).'<br/></td></tr>');
			}
			else{Echo('<a href="../Game/?Scout='.$User[Username].'">Scout</a>');}
			}else{Echo('You cannot view this information as you aren\'t logged in.');}
		Echo('<tr><td colspan="2"><a href="../Game/?Attack='.$User[Username].'"><img alt="Attack" src="../images/icons/Attack.gif"/>&nbsp;Attack</a></td></tr>
			</table><br/>');
		Echo('<br/><br/>');
	}
	}
	else
	{
	die(error('No username set.'));
	}
?>

  </div></div>
  <div id="scrollBottom">&nbsp;</div>
  </div>
	<div id="footer"><a href="http://empireevolution.uk.to/">Home</a> || Copyright  	&#169; <a href="http://alastairdewar.co.uk/">Alastair Dewar</a> 2008</div>
  </body>
</html>