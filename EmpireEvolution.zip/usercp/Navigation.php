<?PHP

				$Database = mysql_connect('alastairdewar.co.uk','adewar','0a4h0d62f4h1d0!!') or die(error('MySQL server down.'));
				$Database = mysql_select_db('adewar_EmpireEvolution',$Database) or die(error('Database Corrupted.'));

if(isset($_GET[Page])){
	if($_GET[Page] != null){
		if(!is_numeric($_GET[Page])){
			$Page = strtolower($_GET[Page]);
			if(strcmp($Page,'changepassword') == 0 || $Page == null){Include("../pages/ChangePassword.ws");}else{
			if(strcmp($Page,'settings') == 0 || $Page == null){Include("../pages/Settings.ws");}else{
			if(strcmp($Page,'changeemail') == 0 || $Page == null){Include("../pages/ChangeEmail.ws");}else{
			if(strcmp($Page,'vacationmode') == 0 || $Page == null){Include("../pages/VacationMode.ws");}else{
			if(strcmp($Page,'uploadavatar') == 0 || $Page == null){Include("../pages/UploadAvatar.ws");}else{
			if(strcmp($Page,'deleteaccount') == 0 || $Page == null){Include("../pages/DeleteAccount.ws");}else{
			if(strcmp($Page,'migrateserver') == 0 || $Page == null){Include("../pages/MigrateServer.ws");}else{
			if(strcmp($Page,'buddylist') == 0 || $Page == null){Include("../pages/Buddylist.ws");}else{
			if(strcmp($Page,'changeempirename') == 0 || $Page == null){Include("../pages/ChangeEmpireName.ws");}else{
			die(error('404 - Page Not Found'));}}}}}}}}}
		}else{
			die(error('Page value is numeric.'));}}else{die(error('Page value is\'nt set.'));}}
else{
		Require("../pages/UserCP.ws");}

?>